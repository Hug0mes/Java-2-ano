import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Rectangle;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Timer;
import java.util.TimerTask;
import java.awt.Window.Type;

public class Design extends JFrame {

	private JPanel contentPane;
	boolean up=true;
	
	 //Launch the application.
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Design frame = new Design();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	//Choque Funtion
	public boolean Choque(JLabel a,JLabel b) {

		boolean x=false;

		Rectangle r1 = a.getBounds();
		Rectangle r2 = b.getBounds();
		
		

		if(r2.intersects(r1)) {
			 x=true;
		}else {
			x=false;
		} 
			return x;
		}
	
	
	
	 //Create the frame.
	 
	public Design() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.setBackground(Color.GRAY);
		
		JLabel Pacman1 = new JLabel(".");
		Pacman1.setBackground(Color.PINK);
		Pacman1.setBounds(274, 264, 27, 33);
		Pacman1.setIcon(new ImageIcon("C:\\Users\\35192\\OneDrive\\Imagens\\img pacman\\Pacmanimg.png"));
		contentPane.add(Pacman1);
		
		JLabel lblNewLabel = new JLabel("...");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\35192\\Desktop\\Borders.jpg"));
		lblNewLabel.setBounds(0, 0, 301, 10);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("...");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\35192\\Desktop\\Borders.jpg"));
		lblNewLabel_1.setBounds(293, 0, 301, 10);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("...");
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\35192\\Desktop\\Borders.jpg"));
		lblNewLabel_2.setBounds(0, 0, 9, 151);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("...");
		lblNewLabel_2_1.setIcon(new ImageIcon("C:\\Users\\35192\\Desktop\\Borders.jpg"));
		lblNewLabel_2_1.setBounds(0, 200, 9, 161);
		contentPane.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_3 = new JLabel("...");
		lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\35192\\Desktop\\Borders.jpg"));
		lblNewLabel_3.setBounds(0, 351, 301, 10);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_3_1 = new JLabel("...");
		lblNewLabel_3_1.setIcon(new ImageIcon("C:\\Users\\35192\\Desktop\\Borders.jpg"));
		lblNewLabel_3_1.setBounds(293, 351, 301, 10);
		contentPane.add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("...");
		lblNewLabel_2_1_1.setIcon(new ImageIcon("C:\\Users\\35192\\Desktop\\Borders.jpg"));
		lblNewLabel_2_1_1.setBounds(575, 200, 9, 161);
		contentPane.add(lblNewLabel_2_1_1);
		
		JLabel lblNewLabel_2_1_1_1 = new JLabel("...");
		lblNewLabel_2_1_1_1.setIcon(new ImageIcon("C:\\Users\\35192\\Desktop\\Borders.jpg"));
		lblNewLabel_2_1_1_1.setBounds(575, -2, 9, 153);
		contentPane.add(lblNewLabel_2_1_1_1);
		
		JLabel lblNewLabel_2_1_2 = new JLabel("...");
		lblNewLabel_2_1_2.setIcon(new ImageIcon("C:\\Users\\35192\\Desktop\\Borders.jpg"));
		lblNewLabel_2_1_2.setBounds(51, 52, 9, 167);
		contentPane.add(lblNewLabel_2_1_2);
		
		JLabel lblNewLabel_2_1_3 = new JLabel("...");
		lblNewLabel_2_1_3.setIcon(new ImageIcon("C:\\Users\\35192\\Desktop\\Borders.jpg"));
		lblNewLabel_2_1_3.setBounds(104, 46, 9, 87);
		contentPane.add(lblNewLabel_2_1_3);
		
		JLabel lblNewLabel_2_1_4 = new JLabel("...");
		lblNewLabel_2_1_4.setIcon(new ImageIcon("C:\\Users\\35192\\Desktop\\Borders.jpg"));
		lblNewLabel_2_1_4.setBounds(104, 175, 9, 87);
		contentPane.add(lblNewLabel_2_1_4);
		
		JLabel lblNewLabel_2_1_5 = new JLabel("...");
		lblNewLabel_2_1_5.setIcon(new ImageIcon("C:\\Users\\35192\\Desktop\\Borders.jpg"));
		lblNewLabel_2_1_5.setBounds(274, 35, 9, 167);
		contentPane.add(lblNewLabel_2_1_5);
		
		JLabel lblNewLabel_2_1_6 = new JLabel("...");
		lblNewLabel_2_1_6.setIcon(new ImageIcon("C:\\Users\\35192\\Desktop\\Borders.jpg"));
		lblNewLabel_2_1_6.setBounds(327, 35, 9, 167);
		contentPane.add(lblNewLabel_2_1_6);
		
		JLabel lblNewLabel_2_1_7 = new JLabel("...");
		lblNewLabel_2_1_7.setIcon(new ImageIcon("C:\\Users\\35192\\Desktop\\Borders.jpg"));
		lblNewLabel_2_1_7.setBounds(389, 35, 9, 167);
		contentPane.add(lblNewLabel_2_1_7);
		
		JLabel lblNewLabel_2_1_8 = new JLabel("...");
		lblNewLabel_2_1_8.setIcon(new ImageIcon("C:\\Users\\35192\\Desktop\\Borders.jpg"));
		lblNewLabel_2_1_8.setBounds(438, 135, 9, 167);
		contentPane.add(lblNewLabel_2_1_8);
		
		JLabel lblNewLabel_2_1_9 = new JLabel("...");
		lblNewLabel_2_1_9.setIcon(new ImageIcon("C:\\Users\\35192\\Desktop\\Borders.jpg"));
		lblNewLabel_2_1_9.setBounds(515, 52, 9, 167);
		contentPane.add(lblNewLabel_2_1_9);
		
		JLabel Tele1 = new JLabel(". .");
		Tele1.setBounds(575, 168, 10, 21);
		contentPane.add(Tele1);
		
		JLabel Tele2 = new JLabel(". .");
		Tele2.setBounds(0, 168, 10, 21);
		contentPane.add(Tele2);
		
		addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
				if(e.getKeyCode()== KeyEvent.VK_W) {
					Pacman1.setIcon(new ImageIcon("C:\\Users\\35192\\eclipse-workspace\\Pacman_604\\imagens\\PacmanUp.png"));
					if (Pacman1.getLocation().y > 10) {
						Pacman1.setLocation(Pacman1.getLocation().x, Pacman1.getLocation().y - 5);
					}
				}
				if(e.getKeyCode()== KeyEvent.VK_S) {
					Pacman1.setIcon(new ImageIcon("C:\\Users\\35192\\eclipse-workspace\\Pacman_604\\imagens\\Pacmandown.png"));
					if (Pacman1.getLocation().y < 315) {
						Pacman1.setLocation(Pacman1.getLocation().x, Pacman1.getLocation().y + 5);
					
					}
				}
				if(e.getKeyCode()== KeyEvent.VK_A) {
					Pacman1.setIcon(new ImageIcon("C:\\Users\\35192\\eclipse-workspace\\Pacman_604\\imagens\\PacmanBack.png"));
					if (Pacman1.getLocation().x > 10) {
						Pacman1.setLocation(Pacman1.getLocation().x  - 5, Pacman1.getLocation().y);
					}
				}
				if(e.getKeyCode()== KeyEvent.VK_D) {
					Pacman1.setIcon(new ImageIcon("C:\\Users\\35192\\OneDrive\\Imagens\\img pacman\\Pacmanimg.png"));
					if (Pacman1.getLocation().x < 545) {
						Pacman1.setLocation(Pacman1.getLocation().x  + 5, Pacman1.getLocation().y);
					}
			
				}
			}
		}); 	
	
	
	
	Timer timer = new Timer();
	timer.schedule(new TimerTask() {
		
		@Override

		public void run() {

			// TODO Auto-generated method stub

			/*
					if(up) {
/*
				if(lblNewLabel_1.getLocation().y>0) {

				lblNewLabel_1.setLocation(lblNewLabel_1.getLocation().x, lblNewLabel_1.getLocation().y-10);

				}else {

				up=false;

				}

			}

				else {   */

			/*		if(lblNewLabel_1.getLocation().y<380) {

						lblNewLabel_1.setLocation(lblNewLabel_1.getLocation().x, lblNewLabel_1.getLocation().y+10);

						}else {

						up=true;

						} 

			}   */

			
			if(Choque(Pacman1,Tele2)) {

				Pacman1.setLocation(Pacman1.getLocation().x  + 535, Pacman1.getLocation().y);
			}
			
			if(Choque(Pacman1,Tele1)) {

				Pacman1.setLocation(Pacman1.getLocation().x  - 535, Pacman1.getLocation().y);
				
			} 
			
			
			
			if(lblNewLabel.getLocation().x > 590) {

				timer.cancel();

				JOptionPane.showConfirmDialog(null,

						"Passou o nivel", "Jogo", JOptionPane.INFORMATION_MESSAGE);

			}
		}}, 20, 20);

	

}
	}
	
	
	
	
	
	
	

